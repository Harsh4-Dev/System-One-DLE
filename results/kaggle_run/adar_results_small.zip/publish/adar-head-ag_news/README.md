---
license: apache-2.0
base_model: convaiinnovations/laya
library_name: pytorch
pipeline_tag: text-classification
tags: [system-one, laya, decision-model, calibration, routing, text-classification, adar]
datasets: [fancyzhx/ag_news]
metrics: [accuracy, f1]
model-index:
- name: adar-head-ag-news
  results:
  - task:
      type: text-classification
      name: Text Classification
    dataset:
      name: ag_news
      type: fancyzhx/ag_news
      split: test
    metrics:
    - type: accuracy
      value: 0.9328
      name: Accuracy (mean of 3 seeds)
    - type: f1
      value: 0.9328
      name: Macro F1 (mean of 3 seeds)
---

# ADAR head for ag_news (on top of convaiinnovations/laya)

**ADAR — Adaptive Deep Architecture Routing** is a System-One decision head. For every input it
reads the frozen Laya (System-One) embedding, one token per answer option (built from the option's
text description) and one token per syllabus expert (TextCNN / RNN / LSTM / GRU), mixes them with a
2-layer transformer and returns typed, calibrated outputs:

* `choice` — a calibrated distribution over world, sports, business, sci_tech
* `noul` per expert — P(this expert is right on this input), used to route between architectures
* `act` — P(the head's own answer is right), used to abstain or escalate

Trained with strictly proper scoring rules (log score + Brier), temperature-scaled on validation data.

## Results (ag_news test set, 7600 rows)

| Model | Family | Syllabus unit | Accuracy | Macro-F1 | NLL | Brier | ECE (TS) | ECE (raw) | AURC | CPU ms/sample | Params |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **ADAR cascade (escalates 36%)** | ADAR (ours) | I-IV | 0.9332 | 0.9332 | 0.2077 | 0.1057 | 0.0111 | 0.0111 | 0.0141 | 189.19 | - |
| **ADAR (ours, mean of 3 seeds)** | ADAR (ours) | I-IV | 0.9328 ± 0.0016 | 0.9328 ± 0.0016 | 0.1973 ± 0.0030 | 0.1033 ± 0.0018 | 0.0092 ± 0.0008 | 0.0093 | 0.0115 | 491.73 | 2.33M |
| Laya zero-shot (typed choice) | System One | III | 0.9253 | 0.9252 | 0.2366 | 0.1203 | 0.0214 | 0.0641 | 0.0167 | 706.27 | 394.78M |
| Logistic Regression (TF-IDF) | scikit-learn | - | 0.9251 | 0.9250 | 0.2410 | 0.1202 | 0.0149 | 0.0149 | 0.0184 | 2.79 | - |
| Average of syllabus experts | Ensemble | I-III | 0.9247 | 0.9246 | 0.2349 | 0.1200 | 0.0164 | 0.0173 | 0.0166 | 17.06 | 16.09M |
| Bi-GRU | Deep learning (syllabus) | III | 0.9241 | 0.9239 | 0.2365 | 0.1218 | 0.0175 | 0.0179 | 0.0164 | 6.16 | 4.04M |
| Bi-LSTM | Deep learning (syllabus) | III | 0.9230 | 0.9228 | 0.2324 | 0.1211 | 0.0140 | 0.0159 | 0.0157 | 6.40 | 4.11M |
| Stacking LogReg (Laya emb + experts) | Ensemble | I-III | 0.9204 | 0.9203 | 0.2323 | 0.1203 | 0.0091 | 0.0188 | 0.0154 | 489.21 | - |
| TextCNN | Deep learning (syllabus) | I-II | 0.9171 | 0.9169 | 0.2580 | 0.1284 | 0.0192 | 0.0171 | 0.0210 | 1.11 | 4.04M |
| Laya encoder + Logistic Regression | System One + sklearn | III | 0.9053 | 0.9052 | 0.2778 | 0.1450 | 0.0123 | 0.0207 | 0.0215 | 472.15 | 394.78M |

QC gates: 14/14 passed (see REPORT.md)

## Files

* `model.safetensors`, `config.json` — the head (2332743 parameters) and its temperature
* `options.safetensors` — encoder embeddings of the option descriptions
* `experts/` — the syllabus experts (one model per stacking fold) and their vocabulary

## Usage

```python
from adar.inference import ADARClassifier
clf = ADARClassifier.from_pretrained("path/to/this/folder", device="cuda")
clf.predict(["NASA's new telescope captured images of a distant galaxy cluster."])
```

## Limitations

* The head is trained for this label set; new labels need new option descriptions *and* retraining
  of the experts (the Laya-only ablation head works with descriptions alone).
* Numbers come from a single train/val/test protocol; see `REPORT.md` for confidence intervals.
