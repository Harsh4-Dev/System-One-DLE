---
license: apache-2.0
base_model: convaiinnovations/laya
library_name: pytorch
pipeline_tag: text-classification
tags: [system-one, laya, decision-model, calibration, routing, text-classification, adar]
datasets: [dair-ai/emotion]
metrics: [accuracy, f1]
model-index:
- name: adar-head-emotion
  results:
  - task:
      type: text-classification
      name: Text Classification
    dataset:
      name: emotion
      type: dair-ai/emotion
      split: test
    metrics:
    - type: accuracy
      value: 0.9200
      name: Accuracy (mean of 3 seeds)
    - type: f1
      value: 0.8790
      name: Macro F1 (mean of 3 seeds)
---

# ADAR head for emotion (on top of convaiinnovations/laya)

**ADAR — Adaptive Deep Architecture Routing** is a System-One decision head. For every input it
reads the frozen Laya (System-One) embedding, one token per answer option (built from the option's
text description) and one token per syllabus expert (TextCNN / RNN / LSTM / GRU), mixes them with a
2-layer transformer and returns typed, calibrated outputs:

* `choice` — a calibrated distribution over sadness, joy, love, anger, fear, surprise
* `noul` per expert — P(this expert is right on this input), used to route between architectures
* `act` — P(the head's own answer is right), used to abstain or escalate

Trained with strictly proper scoring rules (log score + Brier), temperature-scaled on validation data.

## Results (emotion test set, 2000 rows)

| Model | Family | Syllabus unit | Accuracy | Macro-F1 | NLL | Brier | ECE (TS) | ECE (raw) | AURC | CPU ms/sample | Params |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Bi-LSTM | Deep learning (syllabus) | III | 0.9225 | 0.8816 | 0.1919 | 0.1100 | 0.0163 | 0.0168 | 0.0092 | 3.28 | 1.21M |
| Bi-GRU | Deep learning (syllabus) | III | 0.9220 | 0.8823 | 0.1740 | 0.1028 | 0.0184 | 0.0184 | 0.0081 | 3.02 | 1.15M |
| Average of syllabus experts | Ensemble | I-III | 0.9220 | 0.8810 | 0.1777 | 0.1052 | 0.0162 | 0.0200 | 0.0084 | 9.18 | 4.53M |
| **ADAR cascade (escalates 0%)** | ADAR (ours) | I-IV | 0.9220 | 0.8809 | 0.1777 | 0.1054 | 0.0162 | 0.0162 | 0.0084 | 9.56 | - |
| **ADAR (ours, mean of 3 seeds)** | ADAR (ours) | I-IV | 0.9200 ± 0.0019 | 0.8790 ± 0.0054 | 0.1704 ± 0.0005 | 0.1014 ± 0.0005 | 0.0150 ± 0.0007 | 0.0181 | 0.0080 | 387.64 | 2.33M |
| TextCNN | Deep learning (syllabus) | I-II | 0.9055 | 0.8567 | 0.2149 | 0.1231 | 0.0153 | 0.0154 | 0.0122 | 1.06 | 1.15M |
| Stacking LogReg (Laya emb + experts) | Ensemble | I-III | 0.8795 | 0.8155 | 0.3430 | 0.1789 | 0.0177 | 0.0740 | 0.0294 | 384.63 | - |
| Logistic Regression (TF-IDF) | scikit-learn | - | 0.8675 | 0.8039 | 0.3562 | 0.1951 | 0.0307 | 0.0899 | 0.0304 | 1.81 | - |
| Laya encoder + Logistic Regression | System One + sklearn | III | 0.5915 | 0.5056 | 1.0845 | 0.5437 | 0.0321 | 0.2638 | 0.2514 | 375.44 | 394.78M |
| Laya zero-shot (typed choice) | System One | III | 0.5805 | 0.4704 | 1.2109 | 0.5898 | 0.0877 | 0.2397 | 0.3082 | 653.23 | 394.78M |

QC gates: 10/14 passed (see REPORT.md)

## Files

* `model.safetensors`, `config.json` — the head (2332743 parameters) and its temperature
* `options.safetensors` — encoder embeddings of the option descriptions
* `experts/` — the syllabus experts (one model per stacking fold) and their vocabulary

## Usage

```python
from adar.inference import ADARClassifier
clf = ADARClassifier.from_pretrained("path/to/this/folder", device="cuda")
clf.predict(["NASA's new telescope captured images of a distant galaxy cluster."])
```

## Limitations

* The head is trained for this label set; new labels need new option descriptions *and* retraining
  of the experts (the Laya-only ablation head works with descriptions alone).
* Numbers come from a single train/val/test protocol; see `REPORT.md` for confidence intervals.
